<?php
namespace MCF7;

class Init
{
    public function __construct()
    {

    }

    public static function index()
    {

    }
}

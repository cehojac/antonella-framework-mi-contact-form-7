<?php

namespace MCF7\Admin;

class PageAdmin extends Admin
{
    public static function index()
    {

    }

}

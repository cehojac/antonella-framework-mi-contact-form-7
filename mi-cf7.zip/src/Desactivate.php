<?php
namespace MCF7;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
